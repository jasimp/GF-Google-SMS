=== Free SMS OTP Verification for Gravity Forms By Firebase ===
Contributors: wisersteps,omarkasem
Donate link: https://paypal.me/wisersteps
Tags: gravity forms sms, graivty forms otp, gravity forms firebase, gravity forms verification, form sms otp
Requires at least: 4.7
Tested up to: 5.5.1
Stable tag: 1.0.8
Requires PHP: 5.6
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

The best free SMS verification plugin for Gravity Forms, Verify users numbers before submitting the forms.

== Description ==

The best free SMS verification plugin for Gravity Forms, Verify users numbers before submitting the forms, Use Google firebase to edit the sent message to phone numbers by adding your website name.

https://www.youtube.com/watch?v=GwHVKauTSuU

Features:
- Verify 20,000 numbers each month for free
- The Most stable SMS Verification service by Google
- Supports 246 countries and 84 languages
- Supports RTL (Right to left) style
- Show selected countries to the user

Important:
- This is an integration with Firebase
- https://firebase.google.com/docs/auth/web/phone-auth
- Terms of service for Firebase https://firebase.google.com/terms/

== Frequently Asked Questions ==

= Is there a documentation on how to set up the plugin? =

Yes, <a href="https://wisersteps.com/docs/free-sms-otp-verification-for-gravity-forms-by-firebase/setup-plugin-settings/">Documentation</a>

= Is there a video on how to set up the plugin? =

Yes, <a href="https://youtu.be/GwHVKauTSuU">Youtube Video</a>

= Is there a demo for the plugin? =

Yes, here it is <a href="https://wisersteps.com/sites/gf-sms/form/">Demo</a> 
== Screenshots ==

1. Choose field and the countries

2. Field in the works

3. Field in the works (RTL)

4. How to set up the plugin

== Changelog ==

= 1.0.0 =
* Release of the plugin

= 1.0.2 =
* Fix ajax issue

= 1.0.3 =
* Fix conflict with other plugins using firebase

= 1.0.5 =
* Fix issue in multi steps form

= 1.0.6 =
* Fix activation on multisite

= 1.0.7 =
* Add invisible recpatcha option
* Add default country option
* Make field disabled after validation

= 1.0.8 =
* Fix scrolling to field on page opening