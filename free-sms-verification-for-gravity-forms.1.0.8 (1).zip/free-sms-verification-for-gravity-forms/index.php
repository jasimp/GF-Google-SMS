<?php /** Silence is golden.
