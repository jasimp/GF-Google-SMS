jQuery( document ).ready(
	function ($) {
		$( '.gf_sms_select2' ).select2();
	}
);
